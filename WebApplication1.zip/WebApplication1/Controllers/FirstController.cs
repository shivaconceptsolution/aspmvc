﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class FirstController : Controller
    {
        // GET: First
        public ActionResult Index()
        {
            ViewBag.a = 100;
            ViewData["b"] = 200;
            TempData["c"] = 300;
            TempData.Keep();
            // return View();
            return RedirectToAction("Index", "Second");
        }
    }
}