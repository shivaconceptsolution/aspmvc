﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class SwapController : Controller
    {
        // GET: Swap
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        /* public ActionResult Swapcode()  // for request object
         {
             int a =int.Parse(Request["txtnum1"]);
             int b = int.Parse(Request["txtnum2"]);
             a = a + b;
             b = a - b;
             a = a - b;
             ViewBag.data = "Result is " + a + " " + b;
             return View("Index");
         }*/

        public ActionResult Swapcode(string txtnum1,string txtnum2)  // for request object
        {
            int a = int.Parse(txtnum1);
            int b = int.Parse(txtnum2);
            a = a + b;
            b = a - b;
            a = a - b;
            ViewBag.data = "Result is " + a + " " + b;
            return View("Index");
        }
    }
}