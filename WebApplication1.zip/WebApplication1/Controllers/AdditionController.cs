﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class AdditionController : Controller
    {
        // GET: Addition
        public ActionResult Index()
        {
            int a, b, c;
            a = 100;
            b = 200;
            c = a + b;
            ViewBag.data = "Result is " + c;
            return View();
        }

        public ActionResult Substraction()
        {
            int a, b, c;
            a = 1000;
            b = 200;
            c = a - b;
            ViewBag.data = "Result is " + c;
            return View();
        }
    }
}