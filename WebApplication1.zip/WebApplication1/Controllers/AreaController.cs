﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class AreaController : Controller
    {
        // GET: Area
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Triangle t)
        {
            float area = (t.b * t.h)/2;
            ViewBag.data = "Area is " + area;
            return View();
        }
    }
}