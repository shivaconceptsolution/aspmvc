﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class SIController : Controller
    {
        // GET: SI
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult SICode(FormCollection obj)
        {
            float p = float.Parse(obj["txtp"].ToString());
            float r = float.Parse(obj["txtr"].ToString());
            float t = float.Parse(obj["txtt"].ToString());
            float si = (p * r * t) / 100;
            ViewBag.data = "Result is " + si;
            return View("Index");
        }
    }
}